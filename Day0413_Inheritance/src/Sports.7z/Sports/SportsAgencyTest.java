package Sports;

public class SportsAgencyTest {
	public static void main(String[] args) {
		SportsAgency sa = new SportsAgency();
		sa.Start();
	}

}
