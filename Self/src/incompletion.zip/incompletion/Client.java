package incompletion;

public class Client {
	public static void main(String[] args) {
		Admin admin = new Admin();
		
	}
}
